 _________                           __________        __                   __      __            .__       .___
 /   _____/__ ________   ___________  \______   \ _____/  |________  ____   /  \    /  \___________|  |    __| _/
 \_____  \|  |  \____ \_/ __ \_  __ \  |       _// __ \   __\_  __ \/  _ \  \   \/\/   /  _ \_  __ \  |   / __ | 
 /        \  |  /  |_> >  ___/|  | \/  |    |   \  ___/|  |  |  | \(  <_> )  \        (  <_> )  | \/  |__/ /_/ | 
/_______  /____/|   __/ \___  >__|     |____|_  /\___  >__|  |__|   \____/    \__/\  / \____/|__|  |____/\____ | 
        \/      |__|        \/                \/     \/                            \/                         \/ 
		
		

===============================================================================================
File : Super_Retro_World.zip
Author : The low-res arist (Twitter @Pixelart_asset)
Version :
		0.1		04/10/20		Creation
		0.2		17/10/20		Added Godot + Unity support
		0.3		28/10/20		Houses variation
		0.4		04/12/20		Adding a fat tree with some berries
		0.5		27/01/21		Adding a new road
		0.6		19/02/21		Improving the mountain + interior tiles
		0.7		22/02/21		Bird house update

===============================================================================================

Hello and thank you for purchasing this pakage :) I hope it will be useful for you !

===============================================================================================
This package contains :

+ Super_Retro_World.zip
+	README.txt..................This file :)
+ 	atlas_16x.png...............The complete ressource in one file (16x pix size)
+ 	atlas_32x.png...............The complete ressource in one file (32x pix size)
+ 	atlas_48x.png...............The complete ressource in one file (48x pix size)
+	rpgmaker/...................Folder containing the atlas arranged in tileset for RPG MAKER VX, MV, MZ
+	godot/......................Folder container Godot sample project with 2x2 autotiles
+	unity/......................Folder containing the unity TilePalette package
+	screenshots/................Folder containing screenshots from every packs

===============================================================================================
Contact :

Project page : https://the-low-res-artist.itch.io/super-retro-world
Twitter @Pixelart_asset

